# Mallory Milstead
# 3/3/2026
# M5LAB
# Reading from csv file

import csv


def main():
    
    # Open the file
    with open("sales.csv","r") as file:
        # Create a reader object
        reader = csv.DictReader(file)
        
        rows = list(reader)
        
        # Determine all valid product ids from csv file
        valid_products = []
        listToWrite = []
        
        for row in rows:
            
            if row['prodID'] not in valid_products:
                valid_products.append(row["prodID"])
        
        
        # Each row is turned into its own dictionary
        # reader is a collection of dictionaries
        for i in valid_products:
            units = 0
            
            for row in rows:
                
                if i == row['prodID']:
                    units += int(row['units'])
                    total_sales = units * float(row['price'])
            
            print(f"Product ID: {i}\t Total Sales: ${total_sales:.2f}")
            
            salesDict = {i: total_sales}
            listToWrite.append(salesDict)
    
    with open("totalSales.csv", "w", newline = "") as file:
        
        fieldNames = ["productID", "totalSales"]
        writer = csv.DictWriter(file, fieldnames = fieldNames)
        writer.writeheader()
        
        for i in listToWrite:
            
            for k, v in i.items():
                
                writer.writerow({"productID": k, "totalSales": v})

# Call the main
if __name__ == "__main__":
    main()